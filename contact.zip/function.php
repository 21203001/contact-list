<?php

//common start
function runQuery($sql){
    $con = con();
    if(mysqli_query($con,$sql)){
        return true;
    }else{
        die("Database Error : ".mysqli_error($con));
    }
}

function fetchAll($sql){
    $query = mysqli_query(con(),$sql);
    $rows = [];
    while ($row = mysqli_fetch_assoc($query)){
        array_push($rows,$row);
    }
    return $rows;
}

function textFilter($text){
    $text = trim($text);
    $text = htmlentities($text,ENT_QUOTES);
    $text = stripcslashes($text);
    return $text;
}


function old($inputName){
    if (isset($_POST[$inputName])){
        return $_POST[$inputName];
    }else{
        return "";
    }
}

function setError($inputName,$message){
    $_SESSION['error'][$inputName] = $message;
}

function getError($inputName){
    if (isset($_SESSION['error'][$inputName])){
        return $_SESSION['error'][$inputName];
    }else{
        return "";
    }
}

function clearError(){
    $_SESSION['error'] = [];
}
//common end

function contactAdd(){
    $errorStatus = 0;
    $name = "";
    $phone = "";

    if (empty($_POST['name'])){
        setError('name','Name is required!');
        $errorStatus = 1;
    }else{
        if (strlen($_POST['name']) > 30){
            setError('name','Name is too long!');
            $errorStatus = 1;
        }else{
            if (!preg_match("/^[a-zA-Z0-9' ]*$/",$_POST['name'])) {
                setError('name','Only letters, numbers and white space are allowed!');
                $errorStatus = 1;
            }else{
                $name = textFilter($_POST['name']);
            }
        }
    }

    if (empty($_POST['phone'])){
        setError('phone','Phone number is required!');
        $errorStatus = 1;
    }else{
        if (strlen($_POST['phone']) < 4){
            setError('phone','Phone number is too short!');
            $errorStatus = 1;
        }else{
            if (strlen($_POST['phone']) > 16){
                setError('phone','Phone number is too long!');
                $errorStatus = 1;
            }else{
                if (!preg_match("/^[0-9 ]*$/",$_POST['phone'])) {
                    setError('phone','Only numbers and white space are allowed!');
                    $errorStatus = 1;
                }else{
                    $phone = textFilter($_POST['phone']);
                }
            }
        }
    }

    $supportFileType = ["image/jpeg","image/png"];
    if (empty($_FILES['photo']['name'])){
        $newName = "store_photo/default.png";
    }else{
        $tmpFile = $_FILES['photo']['tmp_name'];
        $fileName = $_FILES['photo']['name'];

        if (in_array($_FILES['photo']['type'],$supportFileType)){
            $saveFolder = "store_photo/";
            $newName = $saveFolder.uniqid()."_".$fileName;
            move_uploaded_file($tmpFile,$newName);
        }else{
            setError('photo','File is incorrect!');
            $errorStatus = 1;
        }
    }

    if (!$errorStatus){
        $sql = "INSERT INTO contact (name,phone,photo) VALUES ('$name','$phone','$newName')";
        runQuery($sql);
    }
}

function contact(){
    $sql = "SELECT * FROM contact ORDER BY name";
    return fetchAll($sql);
}

