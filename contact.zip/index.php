<?php
session_start();
require_once "base.php";
require_once "function.php";
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact List</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome/css/all.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row">
            <div class="col-12 my-3">
                <div class="card new-contact">
                    <div class="card-body text-primary">
                        <h4><i class="far fa-address-book mr-1"></i>New Contact</h4>
                        <hr>

                        <?php
                            if (isset($_POST['save'])){
                                contactAdd();
                            }
                        ?>

                        <form method="post" enctype="multipart/form-data">
                            <div class="form-row">
                                <div class="form-group col-6">
                                    <label for="name"><i class="far fa-user mr-1"></i>Name</label>
                                    <input type="text" id="name" name="name" value="<?php echo old('name'); ?>" class="form-control">
                                    <?php if (getError('name')){ ?>
                                        <small class="text-danger font-weight-bold"><?php echo getError('name');?></small>
                                    <?php } ?>
                                </div>

                                <div class="form-group col-6">
                                    <label for="phone"><i class="fas fa-mobile-alt mr-1"></i>Phone</label>
                                    <input type="number" id="phone" name="phone" value="<?php echo old('name'); ?>" class="form-control">
                                    <?php if (getError('phone')){ ?>
                                        <small class="text-danger font-weight-bold"><?php echo getError('phone');?></small>
                                    <?php } ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="photo"><i class="far fa-images mr-1"></i>Contact Photo</label>
                                <input type="file" id="photo" name="photo"  value="<?php echo old('name'); ?>" class="form-control p-1" accept="image/jpeg,image/png">
                                <?php if (getError('photo')){ ?>
                                    <small class="text-danger font-weight-bold"><?php echo getError('photo');?></small>
                                <?php } ?>
                            </div>

                            <hr>
                            <div class="form-group text-right mb-0">
                                <button name="save" class="btn btn-success"><i class="far fa-save mr-1"></i>Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-12">
                <div class="card contact-list mb-3">
                    <div class="card-body text-primary">
                        <h4 class="mb-2"><i class="far fa-list-alt mr-1"></i>Contact List</h4>

                        <table class="table table-hover mb-0">
                            <thead>
                                <tr class="text-primary">
                                    <th><i class="far fa-user"></i></th>
                                    <th>NAME</th>
                                    <th>PHONE NO.</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach (contact() as $c){ ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo $c['photo']; ?>" class="contact-photo" alt="">
                                    </td>
                                    <td><?php echo $c['name']; ?></td>
                                    <td><?php echo $c['phone']; ?></td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-outline-success"><i class="fas fa-phone"></i></a>
                                        <a href="#" class="btn btn-sm btn-outline-warning"><i class="fas fa-comment"></i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php clearError(); ?>
</body>
</html>